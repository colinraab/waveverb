% This Matlab script loads a file containing a measured violin admittance
% and fits a parallel bank of second-order digital filters to it. It then
% calculates the resulting impulse response of that filter structure and
% outputs it as a .wav file for use in a commuted synthesis model.
% 
% by Gary Scavone, McGill University, 2019.

close all;
clear all;

load( 'admittance_hor.mat' );
N = length( avg_admittance );
H = avg_admittance( 1:N/2+1 );
N = length( H );
f = (0:N-1) * fs / N / 2;

fLimits = [ 200 8000 ]; % frequency range over which to fit
nModes = 40;
q = 1.5;        % actually fit nModes*q modes (q is 'extra' factor)
rho = 0.85;     % frequency warping parameter
method = 1;     % Hankel
pcf = fitPoles( H, round(2*nModes*q), rho, 2*fLimits(1)/fs, 2*fLimits(2)/fs, method);

b = [1 0 -1];   % use two-zero nominator with zeros at DC and fs/2
a = [ones(length(pcf), 1) -2*real(pcf) pcf.*conj(pcf)];
omega  = pi*(0:N-1)/N;
eiomp = exp(-1i*(0:2)'*omega);

idx = find( f >= fLimits(1) & f <= fLimits(2) );
N1 = length(idx);
Hm = zeros(N1, 1);
C = zeros(2*N1, length(pcf));
eiomp1 = exp(-1i*(0:2)'*omega(idx));
for i = 1:length(pcf) % calculate FR of each mode filter
  den = a(i, :) * eiomp1;
  num = b * eiomp1;
  Hm = (num./den).';
  C(1:N1, i) = real(Hm);
  C(N1+1:2*N1, i) = imag(Hm);
end
gm = lsqnonneg(C, [real(H(idx)); imag(H(idx))]);

% Plot the resulting fit
Hm = zeros(N, 1);
h = zeros(N, 1);
for i = 1:length(pcf) % calculate FR of each mode filter
  den = a(i, :) * eiomp;
  num = gm(i) * b * eiomp;
  Hm = Hm + (num./den).';
  h = h + impz(gm(i)*b, a(i, :), N);
end
figure;
semilogx(f, db(H(:)), 'k:');
hold on;
semilogx(f, db(Hm(:)), 'b', 'LineWidth', 2);

figure;
h = 0.95*h./(max(abs(h)));
plot(h)
soundsc(h, fs)
audiowrite('violinIR.wav', h, fs);
