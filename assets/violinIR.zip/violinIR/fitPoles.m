function [pc] = fitPoles(H, M, rho, fmin, fmax, method)
% - H is frequency response(s) up to pi (fs/2) in column(s)
% - M is # of complex conjugate poles to estimate
% - rho is freq. warping parameter
% - fmin is the minimum normalized pole frequency to return (fs/2 = 1)
% - fmax is the maximum normalized pole frequency to return
% - method = 1: Hankel (can fit more than one response) or 2: STMCB (only one
% response)
% - returns only positive poles in the range fmin to fmax

if fmax > 1.0
  error('fitPoles: fmax parameter invalid (should be <= 1.0)');
end

[KK, nFRs] = size(H);   % # of FRs, length of each FR
if nFRs < 1 || nFRs > KK
  error('fitPoles: empty matrix or frequency response(s) not in column(s).');
end

K = floor( 1/fmax );    % downsample factor
L = floor(KK/K/2);      % resulting IR lengths
h = zeros(L, nFRs);

% Frequency warping vectors
w = pi * ((0:KK-1)'/ KK);
map = (exp(1i * w) - rho) ./ (1 - rho * exp(1i * w));

% Warp, convert to minimum-phase, and then convert to time-domain
for p = 1:nFRs
  temp1 = spline(angle(map), H(:, p), w); % frequency-warp response
  if K > 1
    bma = ones(1, K); % moving average smoother
    temp1 = filter(bma, 1, temp1);
    temp1 = resample(temp1, 1, K);
  end
  % Theshold lowest magnitudes to -100 dB from peak
  hmag = abs(temp1);
  tval = max(hmag)*10^(-100/20);
  temp1( hmag < tval ) = tval;
  % Convert to minimum phase
  temp2 = exp( fft( fold( ifft( log( temp1 ) ) ) ) );
  % Convert to a real time-domain signal
  if mod(length(temp2), 2) == 1 % odd length
    ir = real(ifft([temp2; conj(flipud(temp2(2:end)))]));
  else
    ir = real(ifft([temp2; real(2*temp2(end)-temp2(end-1)); conj(flipud(temp2(2:end)))]));
  end
  h(:, p) = ir(1:L); % truncate to K/2 samples
end

% Find common poles ---------
if method == 1
  u = [];
  for p = 1:nFRs
    t1 = toeplitz(h(M:L-1, p), h(M:-1:1, p));
    u = [u; t1];
  end
  b = [];
  for p = 1:nFRs
    t1 = h(M+1:L, p);
    b = [b; t1];
  end
  a = -(u' * u) \ (u' * b);
  A = [1 a'];
else
  [~,A] = stmcb(h(:,1), M, M);
end

praw = roots(A); % all poles

% Separate into real and complex conjugates
th = 10*eps(class(praw));
pairs = abs(diff(real(praw)))<th;
pairs = [pairs; 0];
pc = []; % to store complex pairs
N = length(praw);
n = 1;
while n <= N
  if pairs(n) % complex pair
    pc = [pc; praw(n)];
    n = n+2; % jump its conjugate
  else % real single (discard)
    n = n+1; % next
  end
end

% Reflect any unstable poles
stab = abs(pc) < 1;
if ~all(stab)
  for n = 1:length(pc)
    if abs(pc(n)) > 1
      pc(n) = 1/conj(pc(n));
    end
  end
end

% Remove "too damped" modes
rad = abs(pc);
idx = rad > (mean(rad) - 2*std(rad));
pc = pc(idx);

% Dewarp poles
pc = (pc + rho)./(1 + pc.*rho);

% Check pole frequencies and discard any outside fmin to fmax
f = angle(pc) / pi;
idx = (f > fmin) & (f < fmax);
pc = pc(idx);















